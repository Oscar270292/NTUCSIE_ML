import numpy as np
import matplotlib.pyplot as plt

train_data = []
test_data = []
with open('hw6_train.dat.txt', 'r') as file:
    for line in file:
        items = line.strip().split()

        label = int(items[0])

        features = {int(item.split(':')[0]): float(item.split(':')[1]) for item in items[1:]}

        train_data.append((label, features))


with open('hw6_test.dat.txt', 'r') as file:
    for line in file:
        items = line.strip().split()

        label = int(items[0])

        features = {int(item.split(':')[0]): float(item.split(':')[1]) for item in items[1:]}

        test_data.append((label, features))


def get_LR(data, feature, threshold):
    l = [(label, feat) for label, feat in data if feat.get(feature, 0) <= threshold]
    r = [(label, feat) for label, feat in data if feat.get(feature, 0) > threshold]
    return l, r

def square_loss(data, feature, threshold):
    l, r = get_LR(data, feature, threshold)
    if len(l) == 0 or len(r) == 0:
        return float('inf')

    sum_left = 0
    count_left = len(l)

    for label, _ in l:
        sum_left += label

    mean_l = sum_left / count_left if count_left > 0 else float('inf')

    sum_right = 0
    count_right = len(r)

    for label, _ in r:
        sum_right += label

    mean_r = sum_right / count_right if count_right > 0 else float('inf')

    loss_l = np.sum([(label - mean_l) ** 2 for label, _ in l])
    loss_r = np.sum([(label - mean_r) ** 2 for label, _ in r])

    return loss_l + loss_r

def extract_feature(data, feature):
    values = []
    for _, feat in data:
        values.append(feat.get(feature, 0))
    return sorted(set(values))

def find_best_split(data):
    best_feature = None
    best_threshold = None
    best_loss = float('inf')

    for feature in range(1, len(data[0][1]) + 1):
        f_sorted_values = extract_feature(data, feature)

        for i in range(len(f_sorted_values) - 1):
            threshold = np.mean(f_sorted_values[i:i+2])
            loss = square_loss(data, feature, threshold)

            if loss < best_loss:
                best_loss = loss
                best_feature = feature
                best_threshold = threshold

    return best_feature, best_threshold

def build_tree(data):
    if len(set(label for label, _ in data)) == 1:
        return {'leaf': True, 'value': data[0][0]}

    feature, threshold = find_best_split(data)
    l, r = get_LR(data, feature, threshold)

    return {'leaf': False, 'feature': feature, 'threshold': threshold,
            'left': build_tree(l), 'right': build_tree(r)}

def predict(tree, features):
    return tree['value'] if tree['leaf'] else predict(tree['left'], features) if features.get(tree['feature'], 0) <= tree['threshold'] else predict(tree['right'], features)

def last_sq_error(data, array):
    t_labels = [label for label, _ in data]
    t_error = np.mean((np.array(array) - np.array(t_labels)) ** 2)
    return t_error

def random_forest(data, Time):
    forest = []
    for i in range(Time):
        indices = np.random.choice(Time, size=int(0.5 * Time), replace=True)
        bootstrap_data = [data[i] for i in indices]
        tree = build_tree(bootstrap_data)
        forest.append(tree)
        print(i)
    return forest


T = 2000
rf = random_forest(train_data, T)
Eouts_forest = []
for tree in rf:
    forest_predictions = [np.mean([predict(t, feat) for t in rf]) for _, feat in test_data]
    test_error = last_sq_error(test_data, forest_predictions)
    print(test_error)
    Eouts_forest.append(test_error)

Eouts = []
for tree in rf:
    test_predictions = [predict(tree, feat) for _, feat in test_data]
    test_error = last_sq_error(test_data, test_predictions)
    Eouts.append(test_error)
Eins = []
for tree in rf:
    train_predictions = [predict(tree, feat) for _, feat in train_data]
    train_error = last_sq_error(train_data, train_predictions)
    Eins.append(train_error)



train_labels = [label for label, _ in train_data]
test_labels = [label for label, _ in test_data]

G_train_pre = np.mean(np.array([predict(tree, feat) for _, feat in train_data for tree in rf]), axis=0)
G_test_pre = np.mean(np.array([predict(tree, feat) for _, feat in test_data for tree in rf]), axis=0)

Ein_G = np.mean((G_train_pre - np.array(train_labels))**2)
Eout_G = np.mean((G_test_pre - np.array(test_labels))**2)


plt.hist(Eouts, bins=30)
plt.title('Histogram of Eout(gt)')
plt.xlabel('Eout(gt)')
plt.ylabel('Frequency')
plt.show()

plt.figure()
plt.scatter(Eins, Eouts, alpha=0.5)
plt.scatter([Ein_G], [Eout_G], color='red')  # 標記隨機森林的點
plt.xlabel('Ein')
plt.ylabel('Eout')
plt.title('Scatter Plot of Ein and Eout')

plt.figure()
plt.plot(Eouts, label='Eout(gt)')
plt.plot(Eouts_forest, label='Eout(Gt)')
plt.xlabel('Number of Trees')
plt.ylabel('Eout')
plt.title('Eout(gt) vs Eout(Gt)')
plt.legend()
plt.show()

