import numpy as np


train_data = []
test_data = []

with open('hw6_train.dat.txt', 'r') as file:
    for line in file:
        items = line.strip().split()

        label = int(items[0])

        features = {int(item.split(':')[0]): float(item.split(':')[1]) for item in items[1:]}

        train_data.append((label, features))


with open('hw6_test.dat.txt', 'r') as file:
    for line in file:
        items = line.strip().split()

        label = int(items[0])

        features = {int(item.split(':')[0]): float(item.split(':')[1]) for item in items[1:]}

        test_data.append((label, features))

def get_LR(data, feature, threshold):
    l = [(label, feat) for label, feat in data if feat.get(feature, 0) <= threshold]
    r = [(label, feat) for label, feat in data if feat.get(feature, 0) > threshold]
    return l, r

def square_loss(data, feature, threshold):
    l, r = get_LR(data, feature, threshold)
    if len(l) == 0 or len(r) == 0:
        return float('inf')

    sum_left = 0
    count_left = len(l)

    for label, _ in l:
        sum_left += label

    mean_l = sum_left / count_left if count_left > 0 else float('inf')

    sum_right = 0
    count_right = len(r)

    for label, _ in r:
        sum_right += label

    mean_r = sum_right / count_right if count_right > 0 else float('inf')

    loss_l = np.sum([(label - mean_l) ** 2 for label, _ in l])
    loss_r = np.sum([(label - mean_r) ** 2 for label, _ in r])

    return loss_l + loss_r

def extract_feature(data, feature):
    values = []
    for _, feat in data:
        values.append(feat.get(feature, 0))
    return sorted(set(values))

def find_best_split(data):
    best_feature = None
    best_threshold = None
    best_loss = float('inf')

    for feature in range(1, len(data[0][1]) + 1):
        f_sorted_values = extract_feature(data, feature)

        for i in range(len(f_sorted_values) - 1):
            threshold = np.mean(f_sorted_values[i:i+2])
            loss = square_loss(data, feature, threshold)

            if loss < best_loss:
                best_loss = loss
                best_feature = feature
                best_threshold = threshold

    return best_feature, best_threshold

def build_tree(data):
    if len(set(label for label, _ in data)) == 1:
        return {'leaf': True, 'value': data[0][0]}

    feature, threshold = find_best_split(data)
    l, r = get_LR(data, feature, threshold)

    return {'leaf': False, 'feature': feature, 'threshold': threshold,
            'left': build_tree(l), 'right': build_tree(r)}

def predict(tree, features):
    return tree['value'] if tree['leaf'] else predict(tree['left'], features) if features.get(tree['feature'], 0) <= tree['threshold'] else predict(tree['right'], features)

def last_sq_error(data, array):
    t_labels = [label for label, _ in data]
    t_error = np.mean((np.array(array) - np.array(t_labels)) ** 2)
    return t_error

tree = build_tree(train_data)

train_predictions = [predict(tree, feat) for _, feat in train_data]
test_predictions = [predict(tree, feat) for _, feat in test_data]

train_error = last_sq_error(train_data, train_predictions)
test_error = last_sq_error(test_data, test_predictions)

print(f'Eout(g) = {test_error}')